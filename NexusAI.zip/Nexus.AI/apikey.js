
const getAPIKeys = () => {
    if (window.NEXUS_CONFIG) {
        return {
            gemini: window.NEXUS_CONFIG.GEMINI_API_KEY || "AIzaSyBiH7xdMUR7aXK8S1AWvuo1qJu2mqabI4g",
            openai: window.NEXUS_CONFIG.OPENAI_API_KEY || "sk-proj-pLzNccYgL6bdFQZKatWx_#d660WICmGhaJGCVeN5bJeJ2fi5loc6rYXvOtjX7E1vF6M5IdpmQpuT3BlbkFJIpyp40GPHO5Kt4SM83CWlShPS9wxLgKsrzZcJi8141F3C0gEkXfMtLqtX_6xuZbgo-FVzl4EgA",
            claude: window.NEXUS_CONFIG.CLAUDE_API_KEY || "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",
            grok: window.NEXUS_CONFIG.GROK_API_KEY || "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",
            huggingface: window.NEXUS_CONFIG.HUGGINGFACE_TOKEN || false,
            perplexity: window.NEXUS_CONFIG.PERPLEXITY_API_KEY || false,
            cohere: window.NEXUS_CONFIG.COHERE_API_KEY || "zpM6r8q09AALmAtyiW2IpHsm8wjEK15IbSW5YX1G",
            local: window.NEXUS_CONFIG.USE_LOCAL_LLM ? window.NEXUS_CONFIG.LOCAL_LLM_URL : ""
        };
    }

    return {
        gemini: "AIzaSyBiH7xdMUR7aXK8S1AWvuo1qJu2mqabI4g",
        openai: "sk-proj-pLzNccYgL6bdFQZKatWx_#d660WICmGhaJGCVeN5bJeJ2fi5loc6rYXvOtjX7E1vF6M5IdpmQpuT3BlbkFJIpyp40GPHO5Kt4SM83CWlShPS9wxLgKsrzZcJi8141F3C0gEkXfMtLqtX_6xuZbgo-FVzl4EgA",
        claude: "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",
        grok: "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",
        huggingface: false,
        perplexity: false,
        cohere: "zpM6r8q09AALmAtyiW2IpHsm8wjEK15IbSW5YX1G",
        local: ""
    };
};

const NEXUS_API_KEYS = getAPIKeys();

const BACKUP_API_KEYS = {
    gemini: [],
    openai: [],
    claude: []
};

const API_ENDPOINTS = {
    gemini: "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
    openai: "https://api.openai.com/v1/chat/completions",
    claude: "https://api.anthropic.com/v1/messages",
    huggingface: "https://api-inference.huggingface.co/models",
    local: "http://localhost:11434/v1/chat/completions"
};

// 🎯 API MANAGER CLASS (sama seperti sebelumnya)
class NexusAPI {
    constructor() {
        this.keys = { ...NEXUS_API_KEYS };
        this.validateKeys();
    }
    
    validateKeys() {
        console.log("🔍 Validating API keys...");
        for (const [provider, key] of Object.entries(this.keys)) {
            if (key && key.trim() !== "") {
                console.log(`✅ ${provider}: Key present`);
            } else {
                console.log(`⚠️ ${provider}: No key provided`);
            }
        }
        
        // Check if we have at least one working key
        const hasValidKey = Object.values(this.keys).some(key => 
            key && key.trim() !== "" && key !== "http://localhost:11434/v1"
        );
        
        if (!hasValidKey && !this.keys.local) {
            console.error("❌ No valid API keys found!");
            console.info("💡 Please edit js/nexus-config.js and add at least one AI API key");
        }
    }
    
        // 🎯 GET WORKING KEY FOR PROVIDER
    getWorkingKey(provider) {
        // Check primary key first
        const primaryKey = this.keys[provider];
        if (primaryKey && primaryKey.trim() !== "" && !this.failedKeys.has(primaryKey)) {
            return primaryKey;
        }
        
        // Try backup keys
        if (BACKUP_API_KEYS[provider] && BACKUP_API_KEYS[provider].length > 0) {
            for (const backupKey of BACKUP_API_KEYS[provider]) {
                if (backupKey && backupKey.trim() !== "" && !this.failedKeys.has(backupKey)) {
                    return backupKey;
                }
            }
        }
        
        // No working key found
        return null;
    }
    
    // 🎯 MARK KEY AS FAILED
    markKeyFailed(provider, key) {
        this.failedKeys.add(key);
        console.warn(`⚠️ Marked ${provider} key as failed: ${key.substring(0, 20)}...`);
        
        // Try to switch to backup
        const backupKey = this.getWorkingKey(provider);
        if (backupKey && backupKey !== key) {
            this.keys[provider] = backupKey;
            console.log(`🔄 Switched to backup ${provider} key`);
        }
    }
    
    // 🎯 TEST API KEY
    async testKey(provider, key) {
        if (!key || key.trim() === "") return false;
        
        try {
            let testUrl, testOptions;
            
            switch(provider) {
                case 'gemini':
                    testUrl = `${API_ENDPOINTS.gemini}?key=${key}`;
                    testOptions = {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            contents: [{
                                parts: [{ text: "Hello" }]
                            }]
                        })
                    };
                    break;
                    
                case 'openai':
                    testUrl = API_ENDPOINTS.openai;
                    testOptions = {
                        method: 'GET',
                        headers: { 'Authorization': `Bearer ${key}` }
                    };
                    break;
                    
                case 'claude':
                    testUrl = API_ENDPOINTS.claude;
                    testOptions = {
                        method: 'GET',
                        headers: { 
                            'x-api-key': key,
                            'anthropic-version': '2023-06-01'
                        }
                    };
                    break;
                    
                case 'local':
                    testUrl = API_ENDPOINTS.local;
                    testOptions = {
                        method: 'GET'
                    };
                    break;
                    
                default:
                    return false;
            }
            
            const response = await fetch(testUrl, testOptions);
            
            // Some APIs return 400/401 for invalid keys, 200/404 for valid but bad request
            return response.status !== 401 && response.status !== 403;
            
        } catch (error) {
            console.error(`Test failed for ${provider}:`, error);
            return false;
        }
    }
    
    // 🎯 MAKE API REQUEST
    async makeRequest(provider, data, options = {}) {
        const {
            retries = 2,
            timeout = 30000,
            onProgress = null,
            stream = false
        } = options;
        
        // Get working key
        const apiKey = this.getWorkingKey(provider);
        if (!apiKey) {
            throw new Error(`No valid API key for ${provider}`);
        }
        
        // Prepare request
        let url, requestOptions;
        
        switch(provider) {
            case 'gemini':
                url = `${API_ENDPOINTS.gemini}?key=${apiKey}`;
                requestOptions = {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: data.messages?.map(msg => ({
                            role: msg.role === 'user' ? 'user' : 'model',
                            parts: [{ text: msg.content }]
                        })) || data.contents,
                        generationConfig: {
                            temperature: data.temperature || 0.7,
                            maxOutputTokens: data.maxTokens || 2000,
                            topP: data.topP || 0.95,
                            topK: data.topK || 40
                        },
                        safetySettings: data.safetySettings || [
                            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
                            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
                            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
                            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" }
                        ]
                    })
                };
                break;
                
            case 'openai':
                url = API_ENDPOINTS.openai;
                requestOptions = {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        model: data.model || 'gpt-3.5-turbo',
                        messages: data.messages,
                        temperature: data.temperature || 0.7,
                        max_tokens: data.maxTokens || 2000,
                        top_p: data.topP || 0.95,
                        frequency_penalty: data.frequencyPenalty || 0,
                        presence_penalty: data.presencePenalty || 0,
                        stream: stream
                    })
                };
                break;
                
            case 'claude':
                url = API_ENDPOINTS.claude;
                requestOptions = {
                    method: 'POST',
                    headers: {
                        'x-api-key': apiKey,
                        'anthropic-version': '2023-06-01',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        model: data.model || 'claude-3-sonnet-20240229',
                        messages: data.messages,
                        max_tokens: data.maxTokens || 2000,
                        temperature: data.temperature || 0.7,
                        top_p: data.topP || 0.95,
                        stream: stream
                    })
                };
                break;
                
            case 'huggingface':
                const model = data.model || 'microsoft/DialoGPT-large';
                url = `${API_ENDPOINTS.huggingface}/${model}`;
                requestOptions = {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        inputs: data.inputs,
                        parameters: {
                            temperature: data.temperature || 0.7,
                            max_length: data.maxTokens || 2000,
                            top_p: data.topP || 0.95
                        }
                    })
                };
                break;
                
            case 'local':
                url = API_ENDPOINTS.local;
                requestOptions = {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        model: data.model || 'llama2',
                        messages: data.messages,
                        temperature: data.temperature || 0.7,
                        max_tokens: data.maxTokens || 2000,
                        stream: stream
                    })
                };
                break;
                
            default:
                throw new Error(`Unsupported provider: ${provider}`);
        }
        
        // Add timeout
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        requestOptions.signal = controller.signal;
        
        // Retry logic
        for (let attempt = 0; attempt <= retries; attempt++) {
            try {
                console.log(`📡 ${provider} request attempt ${attempt + 1}/${retries + 1}`);
                
                const response = await fetch(url, requestOptions);
                
                clearTimeout(timeoutId);
                
                // Handle different status codes
                if (response.status === 401 || response.status === 403) {
                    this.markKeyFailed(provider, apiKey);
                    throw new Error(`Invalid API key for ${provider}`);
                }
                
                if (response.status === 429) {
                    // Rate limited
                    const retryAfter = response.headers.get('Retry-After') || 5;
                    console.log(`⏳ Rate limited, retrying after ${retryAfter} seconds`);
                    await this.delay(retryAfter * 1000);
                    continue;
                }
                
                if (!response.ok) {
                    throw new Error(`${provider} API error: ${response.status} ${response.statusText}`);
                }
                
                // Handle streaming response
                if (stream && onProgress) {
                    return await this.handleStreamResponse(response, onProgress, provider);
                }
                
                // Handle regular response
                const result = await response.json();
                return this.parseResponse(provider, result);
                
            } catch (error) {
                clearTimeout(timeoutId);
                
                if (attempt === retries) {
                    // Last attempt failed
                    if (error.name === 'AbortError') {
                        throw new Error(`Request timeout for ${provider}`);
                    }
                    
                    // Mark key as failed if it's an auth error
                    if (error.message.includes('Invalid API key') || 
                        error.message.includes('401') || 
                        error.message.includes('403')) {
                        this.markKeyFailed(provider, apiKey);
                    }
                    
                    throw error;
                }
                
                // Exponential backoff
                const delayMs = Math.pow(2, attempt) * 1000 + Math.random() * 1000;
                console.log(`🔄 Retry ${attempt + 1} after ${delayMs}ms`);
                await this.delay(delayMs);
            }
        }
    }
    
        // 🎯 HANDLE STREAMING RESPONSE
    async handleStreamResponse(response, onProgress, provider) {
        const reader = response.body?.getReader();
        if (!reader) {
            throw new Error('Stream not supported');
        }
        
        const decoder = new TextDecoder();
        let accumulatedText = '';
        let buffer = '';
        
        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                
                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';
                
                for (const line of lines) {
                    if (line.trim() === '' || line.includes('[DONE]')) continue;
                    
                    try {
                        const data = JSON.parse(line.replace(/^data: /, ''));
                        const chunk = this.parseStreamChunk(provider, data);
                        
                        if (chunk) {
                            accumulatedText += chunk;
                            onProgress(chunk, accumulatedText);
                        }
                    } catch (e) {
                        // Skip invalid JSON
                    }
                }
            }
            
            return accumulatedText;
        } finally {
            reader.releaseLock();
        }
    }
    
    // 🎯 PARSE STREAM CHUNK
    parseStreamChunk(provider, data) {
        switch(provider) {
            case 'openai':
                return data.choices?.[0]?.delta?.content || '';
            case 'claude':
                return data.delta?.text || '';
            case 'local':
                return data.message?.content || data.response || '';
            default:
                return '';
        }
    }
    
    // 🎯 PARSE REGULAR RESPONSE
    parseResponse(provider, data) {
        switch(provider) {
            case 'gemini':
                return data.candidates?.[0]?.content?.parts?.[0]?.text || 
                       data.candidates?.[0]?.content?.text || 
                       'No response generated';
                
            case 'openai':
                return data.choices?.[0]?.message?.content || 
                       data.choices?.[0]?.text || 
                       'No response generated';
                
            case 'claude':
                return data.content?.[0]?.text || 
                       data.content?.text || 
                       'No response generated';
                
            case 'huggingface':
                return data[0]?.generated_text || 
                       data.generated_text || 
                       JSON.stringify(data);
                
            case 'local':
                return data.message?.content || 
                       data.response || 
                       data.choices?.[0]?.text || 
                       'No response generated';
                
            default:
                return 'Response parsing error';
        }
    }
    
    // 🎯 QUEUE MANAGEMENT
    async addToQueue(provider, data, options = {}) {
        return new Promise((resolve, reject) => {
            const request = {
                provider,
                data,
                options,
                resolve,
                reject,
                timestamp: Date.now()
            };
            
            this.requestQueue.push(request);
            this.processQueue();
        });
    }
    
    async processQueue() {
        if (this.isProcessingQueue || this.requestQueue.length === 0) {
            return;
        }
        
        this.isProcessingQueue = true;
        
        while (this.requestQueue.length > 0) {
            const request = this.requestQueue.shift();
            
            try {
                const result = await this.makeRequest(
                    request.provider, 
                    request.data, 
                    request.options
                );
                request.resolve(result);
            } catch (error) {
                request.reject(error);
            }
            
            // Rate limiting: 1 request per 100ms
            await this.delay(100);
        }
        
        this.isProcessingQueue = false;
    }
    
    // 🎯 UTILITY FUNCTIONS
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    // 🎯 PROVIDER SELECTION
    selectBestProvider(preference = null) {
        const providers = ['gemini', 'openai', 'claude', 'local'];
        
        // Use preferred provider if available
        if (preference && this.keys[preference] && !this.failedKeys.has(this.keys[preference])) {
            return preference;
        }
        
        // Find first available provider
        for (const provider of providers) {
            const key = this.keys[provider];
            if (key && key.trim() !== "" && !this.failedKeys.has(key)) {
                return provider;
            }
        }
        
        // No provider available
        throw new Error('No AI provider available. Please check API keys.');
    }
    
    // 🎯 GET PROVIDER INFO
    getProviderInfo(provider) {
        const info = {
            gemini: {
                name: 'Google Gemini',
                models: ['gemini-pro', 'gemini-pro-vision'],
                maxTokens: 32768,
                supportsVision: true,
                costPer1kTokens: 0.0005
            },
            openai: {
                name: 'OpenAI GPT',
                models: ['gpt-4', 'gpt-4-turbo', 'gpt-3.5-turbo'],
                maxTokens: 16384,
                supportsVision: false,
                costPer1kTokens: 0.03
            },
            claude: {
                name: 'Anthropic Claude',
                models: ['claude-3-opus', 'claude-3-sonnet', 'claude-3-haiku'],
                maxTokens: 200000,
                supportsVision: true,
                costPer1kTokens: 0.015
            },
            local: {
                name: 'Local LLM',
                models: ['llama2', 'mistral', 'codellama'],
                maxTokens: 4096,
                supportsVision: false,
                costPer1kTokens: 0
            }
        };
        
        return info[provider] || {};
    }
    
    // 🎯 CALCULATE TOKEN COST
    calculateCost(provider, tokens) {
        const info = this.getProviderInfo(provider);
        if (!info.costPer1kTokens) return 0;
        
        return (tokens / 1000) * info.costPer1kTokens;
    }
    
    // 🎯 ESTIMATE TOKENS
    estimateTokens(text) {
        // Rough estimation: 1 token ≈ 4 characters for English
        // More accurate: split by words and punctuation
        if (!text) return 0;
        
        // Simple estimation
        const charCount = text.length;
        const wordCount = text.split(/\s+/).length;
        
        // Average of character and word-based estimation
        const tokensByChars = Math.ceil(charCount / 4);
        const tokensByWords = Math.ceil(wordCount * 1.3);
        
        return Math.ceil((tokensByChars + tokensByWords) / 2);
    }
    
    // 🎯 BATCH PROCESSING
    async batchProcess(requests, options = {}) {
        const {
            concurrency = 3,
            onProgress = null
        } = options;
        
        const results = [];
        const errors = [];
        let completed = 0;
        
        // Process in batches
        for (let i = 0; i < requests.length; i += concurrency) {
            const batch = requests.slice(i, i + concurrency);
            const promises = batch.map(async (request, index) => {
                try {
                    const result = await this.makeRequest(
                        request.provider,
                        request.data,
                        request.options
                    );
                    
                    results.push({
                        index: i + index,
                        success: true,
                        data: result
                    });
                } catch (error) {
                    errors.push({
                        index: i + index,
                        success: false,
                        error: error.message
                    });
                } finally {
                    completed++;
                    if (onProgress) {
                        onProgress(completed, requests.length);
                    }
                }
            });
            
            await Promise.all(promises);
        }
        
        return { results, errors };
    }
    
    // 🎯 CLEAR FAILED KEYS
    clearFailedKeys() {
        this.failedKeys.clear();
        console.log('✅ Cleared all failed keys cache');
    }
    
    // 🎯 GET STATUS
    getStatus() {
        const status = {};
        
        for (const [provider, key] of Object.entries(this.keys)) {
            status[provider] = {
                configured: !!(key && key.trim() !== ""),
                failed: this.failedKeys.has(key),
                hasBackup: !!(BACKUP_API_KEYS[provider] && BACKUP_API_KEYS[provider].length > 0)
            };
        }
        
        return status;
    }
}

// 🎯 GLOBAL INSTANCE
let nexusAPIInstance = null;

function getNexusAPI() {
    if (!nexusAPIInstance) {
        nexusAPIInstance = new NexusAPI();
    }
    return nexusAPIInstance;
}

// 🎯 EASY-TO-USE FUNCTIONS
async function chatWithAI(message, options = {}) {
    const api = getNexusAPI();
    const provider = options.provider || api.selectBestProvider();
    
    const chatData = {
        messages: [
            { role: 'system', content: options.systemPrompt || 'You are Nexus AI, a helpful assistant.' },
            { role: 'user', content: message }
        ],
        temperature: options.temperature || 0.7,
        maxTokens: options.maxTokens || 2000,
        model: options.model
    };
    
    return await api.makeRequest(provider, chatData, {
        stream: options.stream || false,
        onProgress: options.onProgress
    });
}

async function generateText(prompt, options = {}) {
    return chatWithAI(prompt, options);
}

async function translateText(text, targetLanguage, options = {}) {
    const prompt = `Translate the following text to ${targetLanguage}:\n\n${text}`;
    return chatWithAI(prompt, options);
}

async function summarizeText(text, options = {}) {
    const prompt = `Please summarize the following text:\n\n${text}`;
    return chatWithAI(prompt, options);
}

// 🎯 INITIALIZE ON LOAD
document.addEventListener('DOMContentLoaded', function() {
    // Auto-initialize API
    const api = getNexusAPI();
    
    // Log status
    console.log('🚀 Nexus API Initialized');
    console.log('📊 API Status:', api.getStatus());
    
    // Test connections in background
    setTimeout(async () => {
        for (const provider of ['gemini', 'openai', 'claude', 'local']) {
            const key = api.keys[provider];
            if (key && key.trim() !== '') {
                try {
                    const isValid = await api.testKey(provider, key);
                    if (isValid) {
                        console.log(`✅ ${provider}: Connection successful`);
                    } else {
                        console.warn(`⚠️ ${provider}: Connection failed`);
                    }
                } catch (error) {
                    console.error(`❌ ${provider}: Test error`, error);
                }
            }
        }
    }, 2000);
});

// 🎯 EXPORT FOR MODULE SYSTEMS
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        NexusAPI,
        getNexusAPI,
        chatWithAI,
        generateText,
        translateText,
        summarizeText
    };
}