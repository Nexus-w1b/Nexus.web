const firebaseConfig = {
    apiKey: "AIzaSyBK-MehTTzURY5jT5stH363Y5_WE4iy-XA",
    authDomain: "volca-tools.firebaseapp.com",
    projectId: "volca-tools",
    storageBucket: "volca-tools.firebasestorage.app",
    messagingSenderId: "262525907487",
    appId: "1:262525907487:web:4abc37fa3b583223569b2a"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);